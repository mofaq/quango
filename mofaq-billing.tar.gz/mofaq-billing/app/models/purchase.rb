class Purchase < ActiveRecord::Base
  before_save :set_token
  before_save :set_status



  
  def to_param
    self.token
  end


 
  def response=(info)
    # CC Response
    %w(amount transaction_id).each do |f|
      self.send("#{f}=", info.params[f])
    end
    # Express Checkout Response
    self.amount = info.params['gross_amount'] if info.params['gross_amount']
  end



  protected



    def set_token
      self.token = ActiveSupport::SecureRandom.hex if token.blank?
    end

    def set_status
      self.status = "pending"
    end

end
