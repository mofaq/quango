# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Paypal3::Application.config.secret_token = 'b1a2d0113c8fa4dfd56b11c320b5a9a50c6f3009c7a3ddb1e4c1bf6a052414ec9e6ca6969a52513641b454ff67014c0f54c8b4bda6acbaa89023aba7ee047d13'
