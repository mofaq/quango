class CreatePurchases < ActiveRecord::Migration
  def self.up
    create_table :purchases do |t|
      t.string :transaction_id
      t.decimal :amount
      t.string :token
      t.string :return_url
      t.string :user
      t.string :group
      t.string :subscription
      t.string :status

      t.timestamps
    end
  end

  def self.down
    drop_table :purchases
  end
end
